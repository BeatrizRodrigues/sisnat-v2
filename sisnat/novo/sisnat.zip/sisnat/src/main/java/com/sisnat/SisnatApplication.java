package com.sisnat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SisnatApplication {

	public static void main(String[] args) {
		SpringApplication.run(SisnatApplication.class, args);
	}

}
